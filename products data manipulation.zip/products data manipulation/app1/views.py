from django.shortcuts import render
from django.views.generic import CreateView,TemplateView,ListView,UpdateView,DeleteView
from app1.models import Product
from django.urls import reverse_lazy
from app1.forms import *
# Create your views here.
class indextemplateview(TemplateView):
    template_name='app1/index.html'
class createproduct(CreateView):
    model=Product
    fields='__all__'
    template_name="app1/createprod_detail.html"
    success_url=reverse_lazy("create")
    #form_class=ProductForm
class show_products(ListView):
    model=Product
    template_name='app1/show_products.html' 
    context_object_name='qs'
class product_update(UpdateView):
    model=Product
    fields='__all__'
    template_name="app1/poducts_update.html"
    success_url=reverse_lazy('ulist')
class ProductListView(ListView):
    model=Product
    fields='__all__'
    template_name="app1/product_update_list.html"
    context_object_name="products"
class Productlist_del(ListView):
    model=Product
    fields='__all__'
    template_name="app1/delete_list.html"
    context_object_name="delelist"
class delete(DeleteView):
    model=Product
    fields='__all__'
    template_name='app1/delete.html'
    success_url=reverse_lazy('dele')